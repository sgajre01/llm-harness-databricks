# Full context versus focused harness

One endpoint: exact deliverable quantity.

| Approach | Correct | Accuracy | Median seconds | Input tokens | Output tokens |
|---|---:|---:|---:|---:|---:|
| baseline | 5/5 | 100.0% | 1.05 | 15,305 | 470 |
| harness | 5/5 | 100.0% | 2.12 | 8,216 | 530 |

Harness improvement: **+0.0 percentage points**. Paired wins/losses/ties: 0/0/5. Paired-bootstrap 95% interval: [+0.0, +0.0] pp. Exact paired p=1.0000.

10,000 paired-bootstrap draws. One model and one observation per approach/question; synthetic cases from one generator. A degenerate bootstrap interval does not establish equivalence.

| Question | Expected | Full context | Harness |
|---|---:|---:|---:|
| pilot-9000 | 22 | 22 ✓ | 22 ✓ |
| pilot-9001 | 34 | 34 ✓ | 34 ✓ |
| pilot-9002 | 0 | 0 ✓ | 0 ✓ |
| pilot-9003 | 0 | 0 ✓ | 0 ✓ |
| pilot-9004 | 39 | 39 ✓ | 39 ✓ |
